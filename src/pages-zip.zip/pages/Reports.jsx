
// src/pages/Reports.jsx
import React from 'react';

const Reports = () => (
  <div className="p-4">
    <h2 className="text-xl font-bold mb-4">Reports</h2>
    <p>View generated reports here.</p>
  </div>
);

export default Reports;
