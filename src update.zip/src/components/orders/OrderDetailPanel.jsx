import React from "react";
import MetaItem from "@/components/MetaItem";
import { useNavigate } from "react-router-dom";

export default function OrderDetailPanel({ order, isAdmin }) {
  const navigate = useNavigate();

  if (!order) {
    return <div className="text-sm text-gray-500 p-4">Loading order details…</div>;
  }

  const handleEdit = () => {
    navigate(`/orders/${order.id}/edit`);
  };

  return (
    <div className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold">Order Info</h2>
        {isAdmin && (
          <button
            className="text-sm text-blue-600 hover:underline"
            onClick={handleEdit}
          >
            Edit Details
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <MetaItem label="Client">{order.client_name || "—"}</MetaItem>
        <MetaItem label="Appraiser">{order.appraiser_name || "—"}</MetaItem>

        <MetaItem label="Status">{order.status || "—"}</MetaItem>
        <MetaItem label="Due Date">
          {order.due_date ? new Date(order.due_date).toLocaleDateString() : "—"}
        </MetaItem>

        <MetaItem label="Address">{order.address || "—"}</MetaItem>
        <MetaItem label="City">{order.city || "—"}</MetaItem>
        <MetaItem label="State">{order.state || "—"}</MetaItem>
        <MetaItem label="Zip">{order.zip || "—"}</MetaItem>

        <MetaItem label="Report Type">{order.report_type || "—"}</MetaItem>
        <MetaItem label="Property Type">{order.property_type || "—"}</MetaItem>

        <MetaItem label="Base Fee">
          {order.base_fee !== null && order.base_fee !== undefined
            ? `$${order.base_fee}`
            : "—"}
        </MetaItem>
        {isAdmin && (
          <MetaItem label="Appraiser Fee">
            {order.appraiser_fee !== null && order.appraiser_fee !== undefined
              ? `$${order.appraiser_fee}`
              : "—"}
          </MetaItem>
        )}
        {isAdmin && (
          <MetaItem label="Appraiser Split">
            {order.appraiser_split !== null && order.appraiser_split !== undefined
              ? `${order.appraiser_split}%`
              : "—"}
          </MetaItem>
        )}

        {isAdmin && (
          <MetaItem label="Client Invoice #">
            {order.client_invoice || "—"}
          </MetaItem>
        )}
        {isAdmin && (
          <MetaItem label="Paid Status">{order.paid_status || "—"}</MetaItem>
        )}

        <MetaItem label="Notes">{order.notes || "—"}</MetaItem>
        <MetaItem label="Site Visit">
          {order.site_visit_at
            ? new Date(order.site_visit_at).toLocaleString()
            : "—"}
        </MetaItem>

        {/* Optional: Show timestamps only in edit screen */}
        {isAdmin && (
          <>
            <MetaItem label="Created At">
              {order.created_at
                ? new Date(order.created_at).toLocaleString()
                : "—"}
            </MetaItem>
            <MetaItem label="Updated At">
              {order.updated_at
                ? new Date(order.updated_at).toLocaleString()
                : "—"}
            </MetaItem>
          </>
        )}
      </div>
    </div>
  );
}




