
// src/pages/Settings.jsx
import React from 'react';

const Settings = () => (
  <div className="p-4">
    <h2 className="text-xl font-bold mb-4">Settings</h2>
    <p>Here you can update your preferences.</p>
  </div>
);

export default Settings;
